

<img src="<?php echo e(asset('owo-water.png')); ?>" width="100px" alt=""><?php /**PATH /var/www/html/invoice-owo/resources/views/components/application-logo.blade.php ENDPATH**/ ?>