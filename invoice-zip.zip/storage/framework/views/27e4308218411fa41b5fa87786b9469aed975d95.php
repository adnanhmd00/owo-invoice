<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Bank Details</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="container" style="margin-top: 100px; width: 500px;">
        <?php if(Session::get('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session::get('success')); ?>

            </div>
        <?php endif; ?>
        <div class="text-center"><a href="/" class="btn btn-primary btn-sm m-2">Go Home</a></div>
        <div class="text-center card p-4 shadow">
            <h1>Add Bank Details</h1>
            <form action="<?php echo e(route('update-bank-details', $bank->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                 <div class="form-group text-left">
                    <input type="text" name="ac_holder" value="<?php echo e($bank->ac_holder); ?>" class="form-control" placeholder="Owo Technologies Pvt Ltd (Ac Holder Name)" autocomplete="off">
                    <?php $__errorArgs = ['ac_holder'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small text-left"> <?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group text-left">
                    <input type="text" name="bank_name" value="<?php echo e($bank->bank_name); ?>" class="form-control" placeholder="ICICI Bank Ltd (Bank Name)" autocomplete="off">
                    <?php $__errorArgs = ['bank_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small text-left"> <?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group text-left">
                    <input type="text" name="ac_no" value="<?php echo e($bank->ac_no); ?>" class="form-control" placeholder="123456789 (Ac Number)" autocomplete="off">
                    <?php $__errorArgs = ['ac_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small text-left"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                 <div class="form-group text-left">
                    <input type="text" name="ifsc" value="<?php echo e($bank->ifsc); ?>" class="form-control" placeholder="ICICI1234 (Branch IFSC)" autocomplete="off">
                    <?php $__errorArgs = ['ifsc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small text-left"> <?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="text-center">
                    <button class="btn btn-primary">Edit Product</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html><?php /**PATH /var/www/html/invoice-owo/resources/views/edit-bank-details.blade.php ENDPATH**/ ?>