<?php $__env->startSection('content'); ?>
    <div class="container mt-3" style="width: 500px;">
        <?php if(Session::get('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session::get('success')); ?>

            </div>
        <?php endif; ?>
        <div class="text-center card p-4 shadow">
            <h3>Add Product Name & HSN</h3>
            <form action="<?php echo e(route('add-product')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group text-left">
                    <label for="product_name" class="p-0 mb-0 small"><strong>Product Name</strong></label>
                    <input type="text" name="product_name" value="<?php echo e(old('product_name')); ?>" class="form-control"
                        placeholder="Enter Product Name" autocomplete="off">
                    <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small text-left"> <?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group text-left">
                    <label for="product_name" class="p-0 mb-0 small"><strong>Product HSN</strong></label>
                    <input type="text" name="hsn" value="<?php echo e(old('hsn')); ?>" class="form-control"
                        placeholder="Enter Product HSN" autocomplete="off">
                    <?php $__errorArgs = ['hsn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small text-left"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group text-left">
                    <label for="product_name" class="p-0 mb-0 small"><strong>GST %</strong></label>
                    <input type="text" name="gst" value="<?php echo e(old('gst')); ?>" class="form-control"
                        placeholder="Enter Product GST" autocomplete="off">
                    <?php $__errorArgs = ['hsn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small text-left"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="text-center">
                    <button class="btn btn-primary btn-sm">Add Product</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/invoice-owo/resources/views/add-product-hsn.blade.php ENDPATH**/ ?>