<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3 class="text-center bg-secondary text-light">All Invoices</h3>
        <div class="card  p-3 shadow table-responsive">
            <?php if(Session::get('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session::get('success')); ?>

                </div>
            <?php endif; ?>
            <table id="example" class="table text-center normal-font" style="width:100%;">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Customer Name</th>
                        <th>Mobile No.</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1 ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><div class="small"><?php echo e($product->customer_name_billing); ?></div></td>
                        <td><div class="small"><?php echo e($product->mobile_no); ?></div></td>
                        <td><a href="<?php echo e(route('view-invoice', ['mobile_no' => $product->mobile_no])); ?>" target="_blank" class="btn btn-primary btn-sm">View Invoice</a></td>
                        <td><a href="/edit-invoice/<?php echo e($product->invoice); ?>" target="_blank" class="btn btn-primary btn-sm">Edit</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/invoice-owo/resources/views/welcome.blade.php ENDPATH**/ ?>