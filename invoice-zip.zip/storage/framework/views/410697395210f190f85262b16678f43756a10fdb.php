<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3 class="text-center bg-secondary text-light">Sale Bills Search Result</h3>
        <form action="<?php echo e(route('search')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group m-3">
                <label for="advance"><strong>Advanced Search</strong></label>
                <div class="row">
                    <div class="col-md-10">
                        <input type="text" name="search" class="form-control" placeholder="Advanced Search" autocomplete="off">
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-primary btn-block">Search</button>
                    </div>
                </div>
            </div>
            <?php if(Session::get('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session::get('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(Session::get('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session::get('error')); ?>

                </div>
            <?php endif; ?>
        </form>
        <div class="card  p-3 shadow table-responsive">
            <table id="example" class="table text-center normal-font" style="width:100%;">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Customer Name</th>
                        <th>Product Name</th>
                        <th>Quantity</th>
                        <th>HSN</th>
                        <th>Mobile No.</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1 ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><div class="small">
                            <?php $customer = App\Models\SaleBill::where('invoice', $product->invoice)->first();?>
                            <?php echo e($customer->customer_name_billing); ?>

                        </div></td>
                        <td><div class="small"><?php echo e(substr($product->product_name, 0, 26)); ?><?php if($product->product_name >= 26): ?>...<?php endif; ?></div></td>
                        <td><div class="small"><?php echo e($product->quantity); ?></div></td>
                        <td><div class="small"><?php echo e($product->hsn); ?></div></td>
                        <td><div class="small"><?php echo e($product->mobile_no); ?></div></td>
                        <td><a href="<?php echo e(route('view-sale-invoice', ['invoice_no' => $product->invoice])); ?>" target="_blank" class="btn btn-primary btn-sm">View Invoice</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/invoice-owo/resources/views/search-result.blade.php ENDPATH**/ ?>