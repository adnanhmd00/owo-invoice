<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3 class="text-center bg-secondary text-light">All Admin List</h3>
        <div class="card  p-3 shadow table-responsive">
            <?php if(Session::get('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session::get('success')); ?>

                </div>
            <?php endif; ?>
            <table id="example" class="table text-center normal-font" style="width:100%;">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php    $i = 1;
                    ?>
                    <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td>
                                <div class="small"><?php echo e($admin->name); ?></div>
                            </td>
                            <td>
                                <div class="small"><?php echo e($admin->email); ?></div>
                            </td>
                            <td>
                                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#myModal-<?php echo e($admin->id); ?>">Edit</button></td>

                            <!-- The Modal -->
                            <div class="modal" id="myModal-<?php echo e($admin->id); ?>">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h4 class="modal-title">Edit Profile</h4>
                                            <button type="button" class="close"
                                                data-dismiss="modal">&times;</button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="<?php echo e(route('update', $admin->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <div class="form-group text-left">
                                                    <label for="name" class="p-0 mb-0">Name</label>
                                                    <input type="text" name="name" 
                                                        value="<?php echo e($admin->name); ?>" class="form-control"
                                                        placeholder="Enter Name" autocomplete="off">
                                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small text-left">
                                                        <?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <div class="form-group text-left">
                                                    <label for="email" class="p-0 mb-0">Email</label>
                                                    <input type="text" name="email" value="<?php echo e($admin->email); ?>" readonly
                                                        class="form-control" placeholder="Enter Email"
                                                        autocomplete="off">
                                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small text-left">
                                                        <?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <?php if($admin->email == Auth::user()->email): ?>
                                                <div class="form-group text-left">
                                                    <label for="password" class="p-0 mb-0">Password</label>
                                                    <input type="password" name="password" value="<?php echo e($admin->password); ?>"
                                                        class="form-control" placeholder="Enter Password"
                                                        autocomplete="off">
                                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small text-left">
                                                        <?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <?php endif; ?>
                                                <div class="text-center">
                                                    <button class="btn btn-primary btn-sm">Update Product</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/invoice-owo/resources/views/profile.blade.php ENDPATH**/ ?>