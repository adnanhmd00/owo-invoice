<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid text-center">
                <div class="row mb-2">
                </div>
            </div>
        </section>
        <section class="content">
            <div class="card p-3" style="width: 650px; margin: 0 auto;">
                <div class="text-center">
                    <div class="container">
                        <?php if(Session::get('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session::get('success')); ?>

                            </div>
                        <?php endif; ?>
                        
                        <h1>Bulk Excel Upload</h1>
                        <p>If You Haven't Added Products Name, HSN & GST, The invoice will not show accurate data.</p>
                        <p class="small" id="blink">It's recommended to add Products Name, HSN & GST first.</p>
                    </div>
                    <form action="<?php echo e(route('bulk-excel-import')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group mb-4">
                            <div class="custom-file text-left">
                                <input type="file" name="file" class="custom-file-input" id="customFile" required>
                                <label class="custom-file-label" for="customFile">Choose file</label>
                            </div>
                        </div>
                        <button class="btn btn-primary btn-sm">Upload Excel</button>
                        <a class="btn btn-primary btn-sm" href="<?php echo e(asset('excel-import-template.xlsx')); ?>">Download Sample</a>
                        <a class="btn btn-primary btn-sm" href="<?php echo e(route('truncateTable')); ?>">Clear Table</a>
                    </form>
                </div>
            </div>

            
        </section>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/invoice-owo/resources/views/product-bulk-upload.blade.php ENDPATH**/ ?>