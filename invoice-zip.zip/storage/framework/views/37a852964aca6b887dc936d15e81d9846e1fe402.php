<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3 class="text-center bg-secondary text-light">Sale Bills</h3>
        <form action="<?php echo e(route('search')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group m-3">
                <label for="advance">Advance Search</label>
                <div class="row">
                    <div class="col-md-10">
                        <input type="text" name="search" class="form-control" placeholder="Advance Search" autocomplete="off">
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-primary btn-block">Search</button>
                    </div>
                </div>
            </div>
        </form>
        <div class="card  p-3 shadow table-responsive">
            <table id="example" class="table text-center normal-font" style="width:100%;">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Customer Name</th>
                        <th>Mobile No.</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1 ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><div class="small">
                            <?php $customer = App\Models\SaleBill::where('invoice', $product->invoice)->first();?>
                            <?php echo e($customer->customer_name_billing); ?>

                        </div></td>
                        <td><div class="small"><?php echo e($customer->mobile_no); ?></div></td>
                        <td><a href="<?php echo e(route('view-sale-invoice', ['invoice_no' => $product->invoice])); ?>" target="_blank" class="btn btn-primary btn-sm">View Invoice</a></td>
                        <td><a href="/edit-sale-invoice/<?php echo e($product->invoice); ?>" target="_blank" class="btn btn-primary btn-sm">Edit</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/invoice-owo/resources/views/sale-bill.blade.php ENDPATH**/ ?>