<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3 class="text-center bg-secondary text-light">All Products & HSN</h3>
        <div class="card  p-3 shadow table-responsive">
            <?php if(Session::get('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session::get('success')); ?>

                </div>
            <?php endif; ?>
            <table id="example" class="table text-center normal-font" style="width:100%;">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Product Name</th>
                        <th>HSN</th>
                        <th>%</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php    $i = 1;
                    ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td>
                                <div class="small"><?php echo e($product->product_name); ?></div>
                            </td>
                            <td>
                                <div class="small"><?php echo e($product->hsn); ?></div>
                            </td>
                            <td>
                                <div class="small"><?php echo e($product->gst); ?>%</div>
                            </td>
                            <td><button class="btn btn-primary btn-sm" data-toggle="modal"
                                    data-target="#myModal-<?php echo e($product->id); ?>">Edit</button></td>

                            <!-- The Modal -->
                            <div class="modal" id="myModal-<?php echo e($product->id); ?>">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h4 class="modal-title">Modal Heading</h4>
                                            <button type="button" class="close"
                                                data-dismiss="modal">&times;</button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="<?php echo e(route('update-product', $product->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <div class="form-group text-left">
                                                    <label for="product_name" class="p-0 mb-0">Product Name</label>
                                                    <input type="text" name="product_name"
                                                        value="<?php echo e($product->product_name); ?>" class="form-control"
                                                        placeholder="Enter Product Name" autocomplete="off">
                                                    <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small text-left">
                                                        <?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <div class="form-group text-left">
                                                    <label for="product_name" class="p-0 mb-0">Product HSN</label>
                                                    <input type="text" name="hsn" value="<?php echo e($product->hsn); ?>"
                                                        class="form-control" placeholder="Enter Product HSN"
                                                        autocomplete="off">
                                                    <?php $__errorArgs = ['hsn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small text-left">
                                                        <?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="form-group text-left">
                                                    <label for="product_name" class="p-0 mb-0">Product GST</label>
                                                    <input type="text" name="gst" value="<?php echo e($product->gst); ?>"
                                                        class="form-control" placeholder="Enter Product GST"
                                                        autocomplete="off">
                                                    <?php $__errorArgs = ['gst'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small text-left">
                                                        <?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="text-center">
                                                    <button class="btn btn-primary btn-sm">Update Product</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/invoice-owo/resources/views/show-product-hsn.blade.php ENDPATH**/ ?>