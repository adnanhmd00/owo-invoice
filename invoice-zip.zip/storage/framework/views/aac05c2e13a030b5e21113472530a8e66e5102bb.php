<?php $__env->startSection('content'); ?>
    <div class="container mt-3" style="width: 500px;">
        <?php if(Session::get('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session::get('success')); ?>

            </div>
        <?php endif; ?>
        <div class="text-center card p-4 shadow">
            <h3>Add Bank Details</h3>
            <form action="<?php echo e(route('add-bank-details')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group text-left">
                    <input type="text" name="ac_holder" value="<?php echo e(old('ac_holder')); ?>" class="form-control"
                        placeholder="Owo Technologies Pvt Ltd (Ac Holder Name)" autocomplete="off">
                    <?php $__errorArgs = ['ac_holder'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small text-left"> <?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group text-left">
                    <input type="text" name="bank_name" value="<?php echo e(old('bank_name')); ?>" class="form-control"
                        placeholder="ICICI Bank Ltd (Bank Name)" autocomplete="off">
                    <?php $__errorArgs = ['bank_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small text-left"> <?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group text-left">
                    <input type="text" name="ac_no" value="<?php echo e(old('ac_no')); ?>" class="form-control"
                        placeholder="123456789 (Ac Number)" autocomplete="off">
                    <?php $__errorArgs = ['ac_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small text-left"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group text-left">
                    <input type="text" name="branch" value="<?php echo e(old('branch')); ?>" class="form-control"
                        placeholder="Gurgaon, Haryana (Branch Name)" autocomplete="off">
                    <?php $__errorArgs = ['branch'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small text-left"> <?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group text-left">
                    <input type="text" name="ifsc" value="<?php echo e(old('ifsc')); ?>" class="form-control"
                        placeholder="ICICI1234 (Branch IFSC)" autocomplete="off">
                    <?php $__errorArgs = ['ifsc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small text-left"> <?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="text-center">
                    <button class="btn btn-primary btn-sm">Add Bank Details</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/invoice-owo/resources/views/add-bank-details.blade.php ENDPATH**/ ?>