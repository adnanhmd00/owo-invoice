<?php $__env->startSection('content'); ?>
    <div class="container mt-3" style="width: 1200px;">
        <?php if(Session::get('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session::get('success')); ?>

            </div>
        <?php endif; ?>
        
                <h3 class="text-center bg-light ">Bank Accounts</h3>
        <div class="text-center p-4 shadow">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Bank Name</th>
                            <th>Ac Holder</th>
                            <th>Ac No.</th>
                            <th>IFSC</th>
                            <th>Action</th>
                        </tr>
                        <?php $i = 1 ?>
                        <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($bank->bank_name); ?></td>
                                <td><?php echo e($bank->ac_holder); ?></td>
                                <td><?php echo e($bank->ac_no); ?></td>
                                <td><?php echo e($bank->ifsc); ?></td>
                                <td><?php if($bank->status == 1): ?> <div class="text-success">Active</div> <?php else: ?> <div class="text-danger"> Inactive </div> <?php endif; ?></td>
                                <td><a href="<?php echo e(route('edit-bank-details', $bank->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('change-bank-status', $bank->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-primary btn-sm">Change Status</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </thead>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/invoice-owo/resources/views/bank-details.blade.php ENDPATH**/ ?>