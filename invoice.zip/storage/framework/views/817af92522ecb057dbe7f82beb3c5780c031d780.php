<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HSN Upload</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="container" style="margin-top: 100px; width: 500px;">
        <?php if(Session::get('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session::get('success')); ?>

            </div>
        <?php endif; ?>
        <div class="text-center"><a href="/" class="btn btn-primary btn-sm m-2">Go Home</a></div>
        <div class="text-center card p-4 shadow">
            <h1>Add Product Name & HSN</h1>
            <form action="<?php echo e(route('add-product')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group text-left">
                    <label for="product_name" class="p-0 mb-0">Product Name</label>
                    <input type="text" name="product_name" value="<?php echo e(old('product_name')); ?>" class="form-control" placeholder="Enter Product Name" autocomplete="off">
                    <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small text-left"> <?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group text-left">
                    <label for="product_name" class="p-0 mb-0">Product HSN</label>
                    <input type="text" name="hsn" value="<?php echo e(old('hsn')); ?>" class="form-control" placeholder="Enter Product HSN" autocomplete="off">
                    <?php $__errorArgs = ['hsn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small text-left"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group text-left">
                    <label for="product_name" class="p-0 mb-0">GST %</label>
                    <input type="text" name="gst" value="<?php echo e(old('gst')); ?>" class="form-control" placeholder="Enter Product GST" autocomplete="off">
                    <?php $__errorArgs = ['hsn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small text-left"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="text-center">
                    <button class="btn btn-primary">Add Product</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html><?php /**PATH /var/www/html/invoice-owo/resources/views/add-product-hsn.blade.php ENDPATH**/ ?>